---
name: Aetheris Peak
colors:
  surface: '#fdf8f8'
  surface-dim: '#ddd9d8'
  surface-bright: '#fdf8f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f7f3f2'
  surface-container: '#f1edec'
  surface-container-high: '#ebe7e6'
  surface-container-highest: '#e5e2e1'
  on-surface: '#1c1b1b'
  on-surface-variant: '#444748'
  inverse-surface: '#313030'
  inverse-on-surface: '#f4f0ef'
  outline: '#747878'
  outline-variant: '#c4c7c7'
  surface-tint: '#5f5e5e'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#1c1b1b'
  on-primary-container: '#858383'
  inverse-primary: '#c9c6c5'
  secondary: '#5f5e60'
  on-secondary: '#ffffff'
  secondary-container: '#e2dfe1'
  on-secondary-container: '#636264'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#1d1b1a'
  on-tertiary-container: '#868381'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e5e2e1'
  primary-fixed-dim: '#c9c6c5'
  on-primary-fixed: '#1c1b1b'
  on-primary-fixed-variant: '#474646'
  secondary-fixed: '#e4e2e4'
  secondary-fixed-dim: '#c8c6c8'
  on-secondary-fixed: '#1b1b1d'
  on-secondary-fixed-variant: '#474649'
  tertiary-fixed: '#e6e1df'
  tertiary-fixed-dim: '#cac6c3'
  on-tertiary-fixed: '#1d1b1a'
  on-tertiary-fixed-variant: '#484645'
  background: '#fdf8f8'
  on-background: '#1c1b1b'
  surface-variant: '#e5e2e1'
  status-success: '#34C759'
  status-warning: '#FF9F0A'
  status-danger: '#FF453A'
  surface-card: '#FFFFFF'
  border-subtle: rgba(0,0,0,0.08)
  glass-fill: rgba(255,255,255,0.7)
typography:
  hero:
    fontFamily: Inter
    fontSize: 64px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  section-title:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.3'
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '500'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: '1.2'
    letterSpacing: 0.02em
  hero-mobile:
    fontFamily: Inter
    fontSize: 40px
    fontWeight: '700'
    lineHeight: '1.1'
  section-mobile:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.2'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  container-max: 1440px
  gutter: 24px
  margin-mobile: 20px
  margin-desktop: 80px
  section-gap: 120px
---

## Brand & Style

The design system is engineered to evoke the precision of a high-end gallery and the technical sophistication of an aerospace interface. It targets a premium demographic of vehicle exhibitors and high-net-worth investors who value clarity, exclusivity, and effortless performance.

The aesthetic follows a **High-End Minimalist** movement with **Glassmorphic** accents. It utilizes deep blacks, stark whites, and a signature electric blue to create a sense of "digital luxury." Visual hierarchy is established through extreme contrast and generous negative space, ensuring the product (the vehicles) remains the undisputed hero. The interface should feel silent, responsive, and inevitable.

## Colors

The palette is strictly curated to reflect the Apple-inspired "Pro" ecosystem. 

- **Primary & Secondary:** Used for typography and deep-surfaces to ground the interface in premium weight.
- **Background:** A soft, neutral grey-white that reduces eye strain and provides a sophisticated canvas for cards and modals.
- **Accent:** Reserved exclusively for calls-to-action (CTAs), active states, and selection highlights within the interactive map.
- **Glassmorphism:** Navigation bars and overlays should utilize the `glass-fill` color with a `20px` backdrop blur to maintain context without visual clutter.

## Typography

This design system utilizes **Inter** as a functional alternative to SF Pro, maintaining a clean, grotesque structure that excels in both legibility and editorial impact. 

- **Tracking:** Use tighter letter-spacing for large headlines to create a "compact luxury" feel. Labels and captions should have slightly increased tracking for clarity at small sizes.
- **Hierarchy:** Reserve the `hero` style for high-impact landing sections. Use `label-sm` in uppercase for category tags and status indicators to add a technical, architectural feel.

## Layout & Spacing

The system employs a **Fluid Grid** model based on a 12-column architecture for desktop and a 4-column architecture for mobile. 

- **Whitespace:** Use generous vertical padding (`section-gap`) to allow content to breathe. The luxury feel is derived from the space between elements, not the elements themselves.
- **Interactive Map:** The venue layout should occupy a "full-bleed" container or a large-scale `16:9` frame to maximize the utility of pinch-and-zoom gestures.
- **Breakpoints:** 
  - Mobile: 320px+
  - Tablet: 768px+
  - Desktop: 1024px+
  - Wide: 1440px+

## Elevation & Depth

This design system rejects heavy shadows in favor of **Tonal Layers** and **Subtle Blurs**. 

- **Level 1 (Base):** The `#F5F5F7` background.
- **Level 2 (Cards):** White surfaces with a `rgba(0,0,0,0.04)` 1px border. No shadow.
- **Level 3 (Interactive/Hover):** Cards gain a soft, large-radius shadow `rgba(0,0,0,0.08)` and a slight scale transform (1.02x).
- **Level 4 (Modals/Navigation):** Utilizes `glass-fill` with `backdrop-filter: blur(20px)`. This creates a sense of physical layering without blocking the user's sense of place in the venue map.

## Shapes

The shape language is sophisticated and modern, using a consistent "Rounded" radius that mirrors Apple’s hardware aesthetics (the "squircle" influence).

- **Standard Elements:** Buttons, input fields, and small cards use a `0.5rem` (8px) radius.
- **Large Containers:** Section cards and the main interactive map container use `rounded-xl` (1.5rem/24px) to soften the large layout blocks.
- **Interactive Map Slots:** Should remain sharp or slightly softened (`2px`) to maintain the technical, architectural feel of a floor plan.

## Components

### Buttons
- **Primary:** Background `#0A0A0A`, text `#FFFFFF`, `rounded-lg`. High-gloss finish on hover.
- **Secondary:** Background `transparent`, border `1px solid #0A0A0A`. 
- **Accent:** Background `#0071E3`, for the final "Confirm Booking" action.

### Interactive Map Slots
- **Available:** Subtle green fill with low opacity, transitioning to high opacity on hover.
- **Selected:** Solid `#0071E3` with a glowing drop-shadow.
- **Unavailable/Confirmed:** Neutral grey with a diagonal hatch pattern to indicate "closed" status.

### Input Fields
- Understated design: 1px border `rgba(0,0,0,0.1)`, white background. On focus, the border transitions to `#0071E3` with a subtle outer glow.

### Cards
- Pure white background, 24px internal padding. Content should be center-aligned for "Hero" cards and left-aligned for "Data" cards.

### Dashboard Widgets
- Minimalist line charts using `Recharts`. Remove all grid lines except for the X/Y axes to maintain a clean, "stock market" professional look.